const Contact = require('../models/contact');

exports.getAllContacts = async (req, res) => {
  const contacts = await Contact.find();
  res.json(contacts);
};

exports.getContactById = async (req, res) => {
  const contact = await Contact.findById(req.params.id);
  res.json(contact);
};

exports.addContact = async (req, res) => {
  const newContact = new Contact(req.body);
  await newContact.save();
  res.json(newContact);
};

exports.updateContact = async (req, res) => {
  const updatedContact = await Contact.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updatedContact);
};

exports.deleteContact = async (req, res) => {
  await Contact.findByIdAndDelete(req.params.id);
  res.sendStatus(204);
};

exports.deleteAllContacts = async (req, res) => {
  await Contact.deleteMany();
  res.sendStatus(204);
};
